class AppImages {
  String backgroundImage = 'assets/images/backgroundImage.jpg';
  String backgroundImagePurple = 'assets/images/lightPurpleBackground.jpg';
  String backgrndImage = 'assets/images/backgrnd.png';
}
