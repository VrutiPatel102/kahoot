import 'package:get/get.dart';

class UserRankController extends GetxController {
  var playerName = "Jeel".obs;
  var rank = 1.obs;
  var points = 1453.obs;
  var subtitle = "Big cheese!".obs;
}
