import 'package:get/get.dart';

class CreateBinding extends Bindings{
  @override
  void dependencies() {

  }

}