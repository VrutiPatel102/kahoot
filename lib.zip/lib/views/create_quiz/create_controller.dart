import 'package:get/get.dart';

class CreateController extends GetxController{

}