import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:kahoot_app/views/create_quiz/create_controller.dart';

class CreateQuiz extends GetView<CreateController> {
  const CreateQuiz({super.key});

  @override
  Widget build(BuildContext context) {
    return const Placeholder();
  }
}
